#! /bin/bash
####################################################
# https://www.youtube.com/midfingr                 # 
# script to enable colors in the terminal          #
# make sure the sripts are executable              #
# chmod +x colors.sh and chmod +x remove_colors.sh #                                             
####################################################

cp /home/$USER/.bashrc.backup /home/$USER/.bashrc
cp /etc/bash.bashrc.backup /etc/bash.bashrc
rm /etc/DIR_COLORS