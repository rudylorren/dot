#! /bin/bash
####################################################
# https://www.youtube.com/midfingr                 # 
# script to enable colors in the terminal          #
# make sure the sripts are executable              #
# chmod +x colors.sh and chmod +x remove_colors.sh #                                             
####################################################

cp /home/$USER/.bashrc /home/$USER/.bashrc.backup
cp .bashrc /home/$USER/.bashrc
cp /etc/bash.bashrc /etc/bash.bashrc.backup
cp bash.bashrc /etc/bash.bashrc
cp DIR_COLORS /etc/DIR_COLORS
